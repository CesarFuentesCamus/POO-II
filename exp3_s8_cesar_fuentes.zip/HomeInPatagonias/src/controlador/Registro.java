
package controlador;

import bd.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import modelo.Movie;


public class Registro {
    
    public Registro(){
        
    }
    //método para agregar una pelicula.
    public boolean agregar (Movie movie){
        try{
            Conexion conexion1 = new Conexion();
            Connection cnx = (Connection) conexion1.obtenerConexion();
            
            //Verificar si el ID ya existe
            String checkQuery = "SELECT 1 FROM movie WHERE id = ?";
            PreparedStatement checkStmt = cnx.prepareStatement(checkQuery);
            checkStmt.setInt(1, movie.getId());
            ResultSet rs= (ResultSet) checkStmt.executeQuery();
            
            if(rs.next()){
                //si el ID existe, lanzar un mensaje o arrojar un error.
                System.out.println("El ID ya existe en la base de datos.");
                return false;
            }
            
            String query = "INSERT INTO movie (id, titulo, director, anio, duracion, genero) VALUES (?,?,?,?,?,?)";
            PreparedStatement stmt = cnx.prepareStatement(query);
            stmt.setInt(1, movie.getId());
            stmt.setString(2, movie.getTitulo());
            stmt.setString(3, movie.getDirector());
            stmt.setInt(4, movie.getAnio());
            stmt.setInt(5, movie.getDuracion());
            stmt.setString(6, movie.getGenero());
            stmt.executeUpdate();
            stmt.close();
            cnx.close();
            return true;
            
        }catch(SQLException e){
            System.out.println("Error SQL al agregar la película: " + e.getMessage());
            return false;
        }catch(Exception e){
            System.out.println("Error al agregar película: " + e.getMessage());
            return false;
        }
    }
    
    //método para eliminar una pélicula
    public boolean eliminar(int id){
        try{
            Conexion conexion1 = new Conexion();
            Connection cnx = (Connection) conexion1.obtenerConexion();
            String query = "DELETE FROM movie WHERE id= ?";
            PreparedStatement stmt = cnx.prepareStatement(query);
            stmt.setInt(1,id);
            stmt.executeUpdate();
            stmt.close();
            cnx.close();
            return true;
        }catch(SQLException e){
            System.out.println("Error SQL al eliminar la película: " + e.getMessage());
            return false;
        }catch(Exception e){
            System.out.println("Error al eliminar la película: " + e.getMessage());
            return false;
        }
    }
    
    //método para actualizar la pélicula
    public boolean actualizar (Movie movie){
        try{
            Conexion conexion1 = new Conexion();
            Connection cnx = (Connection) conexion1.obtenerConexion();
            String query = "UPDATE movie set titulo = ?, director = ?, anio = ?, duracion = ?, genero = ? WHERE id=? ";
            PreparedStatement stmt = cnx.prepareStatement(query);
            stmt.setString(1, movie.getTitulo());
            stmt.setString(2, movie.getDirector());
            stmt.setInt(3, movie.getAnio());
            stmt.setInt(4, movie.getDuracion());
            stmt.setString(5, movie.getGenero());
            stmt.setInt(6, movie.getId());
            stmt.executeUpdate();
            stmt.close();
            cnx.close();
            return true;
        }catch(SQLException e){
            System.out.println("Error SQL al actualizar película: " + e.getMessage());
            return false;
        }catch(Exception e){
            System.out.println("Error al actualizar película:  " + e.getMessage());
            return false;
        }
    }
    
    //método para buscar película por id
    public Movie buscarPorId(int id){
        Movie movie =  null ;
        try{
            Conexion conexion1 = new Conexion ();
            Connection cnx = (Connection) conexion1.obtenerConexion();
            String query = "SELECT * FROM movie WHERE id= ?";
            PreparedStatement stmt = cnx.prepareStatement(query);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if(rs.next()){
                movie = new Movie();
                movie.setId(rs.getInt("id"));
                movie.setTitulo(rs.getString("titulo"));
                movie.setDirector(rs.getString("director"));
                movie.setAnio(rs.getInt("anio"));
                movie.setDuracion(rs.getInt("duracion"));
                movie.setGenero(rs.getString("genero"));
            }
            rs.close();
            stmt.close();
            cnx.close();
        }catch(SQLException e){
            System.out.println("Error SQL al buscar la película por ID: " + e.getMessage());
        }catch(Exception e){
            System.out.println("Error al buscar la película por ID: " + e.getMessage()) ;
        }
        return movie;
    }
    
    
    //método para buscar todas la películas
    public List<Movie> buscarTodos(){
        List<Movie> lista = new ArrayList<>();
        
        try{
            Conexion conexion1 = new Conexion ();
            Connection cnx = (Connection) conexion1.obtenerConexion();
            String query = "SELECT * FROM movie";
            PreparedStatement stmt = cnx.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                Movie movie = new Movie();
                 movie.setId(rs.getInt("id"));
                 movie.setTitulo(rs.getString("titulo"));
                 movie.setDirector(rs.getString("director"));
                 movie.setAnio(rs.getInt("anio"));
                 movie.setDuracion(rs.getInt("duracion"));
                 movie.setGenero(rs.getString("genero"));
                 lista.add(movie);
            }
            rs.close();
            stmt.close();
            cnx.close();  
        }catch(SQLException e){
            System.out.println("Error SQL al listar todas las películas: " + e.getMessage());
        }catch(Exception e){
            System.out.println("Error al listar todas las películas: " + e.getMessage());
        }
        return lista;
    }
}

