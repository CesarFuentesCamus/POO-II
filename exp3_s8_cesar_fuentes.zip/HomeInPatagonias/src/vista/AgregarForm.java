
package vista;

import controlador.Registro;
import javax.swing.JOptionPane;
import modelo.Movie;


public class AgregarForm extends javax.swing.JFrame {

   
    public AgregarForm() {
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jbt_guardar = new javax.swing.JButton();
        jbt_limpiar = new javax.swing.JButton();
        jbt_cerrar = new javax.swing.JButton();
        jtf_id = new javax.swing.JTextField();
        jtf_titulo = new javax.swing.JTextField();
        jtf_director = new javax.swing.JTextField();
        jtf_anio = new javax.swing.JTextField();
        jtf_duracion = new javax.swing.JTextField();
        jtf_genero = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Agregar Película");

        jLabel1.setText("ID");

        jLabel2.setText("Titulo");

        jLabel3.setText("Director");

        jLabel4.setText("Año");

        jLabel5.setText("Duración");

        jLabel6.setText("Genero");
        jLabel6.setToolTipText("");

        jbt_guardar.setText("Guardar");
        jbt_guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_guardarActionPerformed(evt);
            }
        });

        jbt_limpiar.setText("Limpiar");
        jbt_limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_limpiarActionPerformed(evt);
            }
        });

        jbt_cerrar.setText("Cerrar");
        jbt_cerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_cerrarActionPerformed(evt);
            }
        });

        jtf_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtf_idActionPerformed(evt);
            }
        });

        jtf_titulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtf_tituloActionPerformed(evt);
            }
        });

        jtf_director.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtf_directorActionPerformed(evt);
            }
        });

        jtf_anio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtf_anioActionPerformed(evt);
            }
        });

        jtf_duracion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtf_duracionActionPerformed(evt);
            }
        });

        jtf_genero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtf_generoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jtf_duracion)
                            .addComponent(jtf_genero)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jbt_guardar)
                                .addGap(44, 44, 44)
                                .addComponent(jbt_limpiar)
                                .addGap(50, 50, 50)
                                .addComponent(jbt_cerrar))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jtf_id)
                            .addComponent(jtf_titulo)
                            .addComponent(jtf_director)
                            .addComponent(jtf_anio))))
                .addGap(39, 39, 39))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jtf_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jtf_titulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jtf_director, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jtf_anio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jtf_duracion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jtf_genero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbt_guardar)
                    .addComponent(jbt_limpiar)
                    .addComponent(jbt_cerrar))
                .addGap(15, 15, 15))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jbt_guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_guardarActionPerformed
        Registro registro = new Registro();
        Movie movie = new Movie();
        
        //validación campos vacios
        if(jtf_id.getText().isEmpty() ||jtf_titulo.getText().isEmpty()|| jtf_director.getText().isEmpty()||
                jtf_anio.getText().isEmpty()||jtf_duracion.getText().isEmpty()){
            
            JOptionPane.showMessageDialog(this, "Los campos son obligatorios");
            return;
        }
            
        
        try{
            //validación de ID
            int id= Integer.parseInt(jtf_id.getText().trim());
            
            if(registro.buscarPorId(id) != null){
                JOptionPane.showMessageDialog(this, "Ya existe una película con este ID.");
                return;
            }
            //obtener los datos de jtf
            movie.setId(id);
            movie.setTitulo(jtf_titulo.getText());
            movie.setDirector(jtf_director.getText());
            movie.setAnio(Integer.parseInt(jtf_anio.getText()));
            movie.setDuracion(Integer.parseInt(jtf_duracion.getText()));
            movie.setGenero(jtf_genero.getText());
            
            //guardar la película
            if(registro.agregar(movie)){
                JOptionPane.showMessageDialog(this, "Película agregada exitosamente.");
                
                //limpiar los campos después de la inserción exitosa
                jtf_id.setText("");
                jtf_titulo.setText("");
                jtf_director.setText("");
                jtf_anio.setText("");
                jtf_duracion.setText("");
                jtf_genero.setText("");
                
            }else{
                JOptionPane.showMessageDialog(this, "Error al agregar película.");
            }  
        }catch (NumberFormatException e){
            JOptionPane.showMessageDialog(this, "¡ Error !, los campos Id, Año y duración deben ser números.");
        }catch(Exception e){
           JOptionPane.showMessageDialog(this, "¡ Error inesperado: " + e.getMessage());
        }                         
    }//GEN-LAST:event_jbt_guardarActionPerformed

    private void jbt_limpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_limpiarActionPerformed
        jtf_id.setText("");
        jtf_titulo.setText("");
        jtf_director.setText("");
        jtf_anio.setText("");
        jtf_duracion.setText("");
        jtf_genero.setText(""); //reinicia la sección del combo box
    }//GEN-LAST:event_jbt_limpiarActionPerformed

    private void jbt_cerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_cerrarActionPerformed
        this.dispose();
    }//GEN-LAST:event_jbt_cerrarActionPerformed

    private void jtf_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtf_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtf_idActionPerformed

    private void jtf_tituloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtf_tituloActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtf_tituloActionPerformed

    private void jtf_directorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtf_directorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtf_directorActionPerformed

    private void jtf_anioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtf_anioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtf_anioActionPerformed

    private void jtf_duracionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtf_duracionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtf_duracionActionPerformed

    private void jtf_generoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtf_generoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtf_generoActionPerformed
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JButton jbt_cerrar;
    private javax.swing.JButton jbt_guardar;
    private javax.swing.JButton jbt_limpiar;
    private javax.swing.JTextField jtf_anio;
    private javax.swing.JTextField jtf_director;
    private javax.swing.JTextField jtf_duracion;
    private javax.swing.JTextField jtf_genero;
    private javax.swing.JTextField jtf_id;
    private javax.swing.JTextField jtf_titulo;
    // End of variables declaration//GEN-END:variables
}
