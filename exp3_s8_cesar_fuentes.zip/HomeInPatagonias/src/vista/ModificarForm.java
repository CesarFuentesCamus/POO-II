
package vista;

import controlador.Registro;
import javax.swing.JOptionPane;
import modelo.Movie;


public class ModificarForm extends javax.swing.JFrame {

    
    public ModificarForm() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jtf_id = new javax.swing.JTextField();
        jbt_buscar = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        jtf_titulo = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jtf_director = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jtf_anio = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jtf_duracion = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jtf_genero = new javax.swing.JTextField();
        jbt_modificar = new javax.swing.JButton();
        jbt_limpiar = new javax.swing.JButton();
        jbt_cerrar = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Modificar Película");

        jLabel1.setText("ID");

        jtf_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtf_idActionPerformed(evt);
            }
        });

        jbt_buscar.setText("Buscar");
        jbt_buscar.setToolTipText("");
        jbt_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_buscarActionPerformed(evt);
            }
        });

        jLabel2.setText("Titulo");

        jtf_titulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtf_tituloActionPerformed(evt);
            }
        });

        jLabel3.setText("Director");

        jtf_director.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtf_directorActionPerformed(evt);
            }
        });

        jLabel4.setText("Año");

        jtf_anio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtf_anioActionPerformed(evt);
            }
        });

        jLabel5.setText("Duración");

        jtf_duracion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtf_duracionActionPerformed(evt);
            }
        });

        jLabel6.setText("Genero");

        jtf_genero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtf_generoActionPerformed(evt);
            }
        });

        jbt_modificar.setText("Modificar");
        jbt_modificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_modificarActionPerformed(evt);
            }
        });

        jbt_limpiar.setText("Limpiar");
        jbt_limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_limpiarActionPerformed(evt);
            }
        });

        jbt_cerrar.setText("Cerrar");
        jbt_cerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_cerrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(69, 69, 69)
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(jtf_id, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(63, 63, 63)
                        .addComponent(jbt_buscar))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel2)
                                    .addGap(18, 18, 18)
                                    .addComponent(jtf_titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(jbt_modificar)
                                    .addGap(49, 49, 49)
                                    .addComponent(jbt_limpiar)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jbt_cerrar)
                                    .addGap(12, 12, 12))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel3)
                                        .addComponent(jLabel4)
                                        .addComponent(jLabel5)
                                        .addComponent(jLabel6))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jtf_director)
                                        .addComponent(jtf_anio)
                                        .addComponent(jtf_duracion)
                                        .addComponent(jtf_genero))))
                            .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jtf_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbt_buscar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jtf_titulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jtf_director, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jtf_anio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jtf_duracion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jtf_genero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbt_modificar)
                    .addComponent(jbt_limpiar)
                    .addComponent(jbt_cerrar))
                .addGap(17, 17, 17))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jtf_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtf_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtf_idActionPerformed

    private void jbt_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_buscarActionPerformed
        Registro registro = new Registro();
        int id;
        
        try{
            id = Integer.parseInt(jtf_id.getText());
            Movie movie = registro.buscarPorId(id);
            
            if(movie != null){
                //colocar los datos de la película en los campos de texto
                jtf_titulo.setText(movie.getTitulo());
                jtf_director.setText(movie.getDirector());
                jtf_anio.setText(String.valueOf(movie.getAnio()));
                jtf_duracion.setText(String.valueOf(movie.getDuracion()));
                jtf_genero.setText(movie.getGenero()); 
            }else{
                JOptionPane.showMessageDialog(this, "Película no encontrada");
            }
        }catch(NumberFormatException e){
            JOptionPane.showMessageDialog(this, "Ppr favor, ingrerse un ID valido");
        }
    }//GEN-LAST:event_jbt_buscarActionPerformed

    private void jtf_tituloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtf_tituloActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtf_tituloActionPerformed

    private void jtf_directorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtf_directorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtf_directorActionPerformed

    private void jtf_anioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtf_anioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtf_anioActionPerformed

    private void jtf_duracionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtf_duracionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtf_duracionActionPerformed

    private void jtf_generoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtf_generoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtf_generoActionPerformed

    private void jbt_modificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_modificarActionPerformed
        Registro registro = new Registro();
       int id, anio, duracion;
       
       try{
           //validar que los campos no esten vacios
           if(jtf_id.getText().isEmpty() ||jtf_titulo.getText().isEmpty()|| jtf_director.getText().isEmpty()||
                jtf_anio.getText().isEmpty()||jtf_duracion.getText().isEmpty()){
            
            JOptionPane.showMessageDialog(this, "Todos los campos deben estar llenos.");
            return;
            }
            id = Integer.parseInt(jtf_id.getText());
            anio = Integer.parseInt(jtf_anio.getText());
            duracion= Integer.parseInt(jtf_duracion.getText());
            
            
            //crear la película modificada
            Movie movie = new Movie();
            movie.setId(id);
            movie.setTitulo(jtf_titulo.getText());
            movie.setDirector(jtf_director.getText());
            movie.setAnio(anio);
            movie.setDuracion(duracion);
            movie.setGenero(jtf_genero.getText());
            
            //actualizar la base de datos
            if(registro.actualizar(movie)){
                JOptionPane.showMessageDialog(this, "Película modificada exitosamente.");
            }else{
                JOptionPane.showMessageDialog(this, "Error al modificar la película");
            } 
       }catch(NumberFormatException e){
          JOptionPane.showMessageDialog(this, "Los campos ID, año y duración deben ser números.");  
       }   
    }//GEN-LAST:event_jbt_modificarActionPerformed

    private void jbt_limpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_limpiarActionPerformed
        jtf_id.setText("");
        jtf_titulo.setText("");
        jtf_director.setText("");
        jtf_anio.setText("");
        jtf_duracion.setText("");
        jtf_genero.setText("");
    }//GEN-LAST:event_jbt_limpiarActionPerformed

    private void jbt_cerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_cerrarActionPerformed
        this.dispose();
    }//GEN-LAST:event_jbt_cerrarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JButton jbt_buscar;
    private javax.swing.JButton jbt_cerrar;
    private javax.swing.JButton jbt_limpiar;
    private javax.swing.JButton jbt_modificar;
    private javax.swing.JTextField jtf_anio;
    private javax.swing.JTextField jtf_director;
    private javax.swing.JTextField jtf_duracion;
    private javax.swing.JTextField jtf_genero;
    private javax.swing.JTextField jtf_id;
    private javax.swing.JTextField jtf_titulo;
    // End of variables declaration//GEN-END:variables
}
